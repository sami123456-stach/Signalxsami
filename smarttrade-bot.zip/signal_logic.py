import yfinance as yf
import pandas as pd

def calculate_signals(symbol="EURUSD=X", interval="1m", period="1d"):
    data = yf.download(tickers=symbol, interval=interval, period=period)
    if data.empty:
        return None

    df = data.copy()
    df["RSI"] = df["Close"].rolling(window=14).apply(lambda x: 100 - (100 / (1 + ((x.diff().fillna(0).clip(lower=0).sum()) / abs(x.diff().fillna(0).clip(upper=0).sum()+0.01)))), raw=False)
    df["EMA12"] = df["Close"].ewm(span=12, adjust=False).mean()
    df["EMA26"] = df["Close"].ewm(span=26, adjust=False).mean()
    df["MACD"] = df["EMA12"] - df["EMA26"]
    df["Signal"] = df["MACD"].ewm(span=9, adjust=False).mean()

    latest = df.iloc[-1]
    if latest["RSI"] < 30 and latest["MACD"] > latest["Signal"]:
        direction = "🔼 CALL"
        reason = "RSI oversold + MACD crossover"
    elif latest["RSI"] > 70 and latest["MACD"] < latest["Signal"]:
        direction = "🔽 PUT"
        reason = "RSI overbought + MACD crossdown"
    else:
        return None

    signal = {
        "asset": symbol.replace("=X", ""),
        "direction": direction,
        "reason": reason
    }
    return signal