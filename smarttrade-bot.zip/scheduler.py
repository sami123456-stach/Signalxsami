import schedule
import time
from datetime import datetime
from signal_logic import calculate_signals
from bot import send_signal

signal_count = 0

def job():
    global signal_count
    if signal_count >= 15:
        return

    now = datetime.now()
    if now.hour == 17:
        signal = calculate_signals()
        if signal:
            send_signal(signal)
            signal_count += 1

schedule.every(1).minutes.do(job)

while True:
    schedule.run_pending()
    time.sleep(1)