from telegram import Bot
from config import BOT_TOKEN, USER_ID

bot = Bot(token=BOT_TOKEN)

def send_signal(signal):
    message = f"""
📈 Signal Alert
Asset: {signal['asset']}
Direction: {signal['direction']}
Expiry: 1 Minute
Reason: {signal['reason']}
"""
    bot.send_message(chat_id=USER_ID, text=message)